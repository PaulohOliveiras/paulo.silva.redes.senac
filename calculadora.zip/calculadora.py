# CAlCULADORA SIMPLES PYTTHON EX1

num01 = 0 
num02 = 0
result = 0
operation = ' '

num01 = float (input (' Insira o primerio numero: '))
operation = (input (' Insira o operação:'))
num02 = float (input (' Insira o primerio numero: '))

if operation == '+':
    result = num01 + num02
elif operation == '-':
    result = num01 '-' num02
elif operation == "*':
    result = num01 '*' num02
elif operation == '/':
    result = num01 '/' num02
else:
    print ('Operação inválida1')
print('{} {} {} {}'.format(num01, operation, num02, result))